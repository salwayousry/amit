import com.example.domain.entity.meals.MealModelResponse

interface MealsRepo {
    suspend fun getMealsCategoriesFromRemote(): MealModelResponse

}