package com.example.domain.usecase.meals

import MealsRepo



class GetMealsCategoriesFromRemote(private val mealsRepo: MealsRepo) {
    suspend operator fun invoke() = mealsRepo.getMealsCategoriesFromRemote()
}