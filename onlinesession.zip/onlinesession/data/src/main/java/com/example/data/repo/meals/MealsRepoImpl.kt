package com.example.data.repo.meals

import MealsRepo
import com.example.data.remote.meals.MealApi
import com.example.domain.entity.meals.MealModelResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MealsRepoImpl(private  val mealsApi: MealApi):MealsRepo {
    override suspend fun getMealsCategoriesFromRemote(): MealModelResponse
      =withContext(Dispatchers.IO){
          return@withContext mealsApi.getMealsRequest()
        }
    }

