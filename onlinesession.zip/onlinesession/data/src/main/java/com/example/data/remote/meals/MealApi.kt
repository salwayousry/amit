package com.example.data.remote.meals

import com.example.domain.entity.meals.MealModelResponse
import retrofit2.http.GET

interface MealApi {
   @GET("api/json/v1/1/categories.php")
    suspend fun getMealsRequest():MealModelResponse
}