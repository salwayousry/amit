package com.example.domain.entity.meals

data class MealModelResponse(
    val categories: List<Category>
)