package com.example.onlinesession.di



import MealsRepo
import com.example.data.remote.meals.MealApi
import com.example.data.repo.meals.MealsRepoImpl


import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
object RepoModule {

    @Provides
    fun providedMealsRepo(
        mealsApi: MealApi,
    ): MealsRepo {
        return MealsRepoImpl(mealsApi)
    }
}